﻿namespace CasaDoCodigo
{
    interface IDataService
    {
        void InicializaDB();
    }
}